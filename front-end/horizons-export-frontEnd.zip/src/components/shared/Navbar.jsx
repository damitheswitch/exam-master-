
    import React, { useContext } from 'react';
    import { Link, useNavigate } from 'react-router-dom';
    import { AuthContext } from '@/App';
    import { Button } from '@/components/ui/button';
    import { LogOut, User, LayoutDashboard, BookOpenCheck, Edit3, Users, FileText } from 'lucide-react';
    import { motion } from 'framer-motion';

    const Navbar = () => {
      const { user, logout, ROLES } = useContext(AuthContext);
      const navigate = useNavigate();

      const handleLogout = () => {
        logout();
        navigate('/login');
      };

      const navItemVariants = {
        hover: { scale: 1.05, color: "var(--accent)" },
        tap: { scale: 0.95 }
      };

      return (
        <nav className="bg-slate-900/80 backdrop-blur-md shadow-lg sticky top-0 z-50">
          <div className="container mx-auto px-4 py-3 flex justify-between items-center">
            <Link to="/" className="text-2xl font-bold gradient-text">
              ExamMaster
            </Link>
            <div className="space-x-2 flex items-center">
              {user ? (
                <>
                  {user.role === ROLES.ADMIN && (
                    <>
                      <motion.div variants={navItemVariants} whileHover="hover" whileTap="tap">
                        <Button variant="ghost" asChild><Link to="/admin"><LayoutDashboard className="mr-2 h-4 w-4" />Admin Dashboard</Link></Button>
                      </motion.div>
                      <motion.div variants={navItemVariants} whileHover="hover" whileTap="tap">
                        <Button variant="ghost" asChild><Link to="/admin/users"><Users className="mr-2 h-4 w-4" />Users</Link></Button>
                      </motion.div>
                       <motion.div variants={navItemVariants} whileHover="hover" whileTap="tap">
                        <Button variant="ghost" asChild><Link to="/admin/questions"><Edit3 className="mr-2 h-4 w-4" />Questions</Link></Button>
                      </motion.div>
                      <motion.div variants={navItemVariants} whileHover="hover" whileTap="tap">
                        <Button variant="ghost" asChild><Link to="/admin/exams"><FileText className="mr-2 h-4 w-4" />Exams</Link></Button>
                      </motion.div>
                    </>
                  )}
                  {user.role === ROLES.TEACHER && (
                    <>
                      <motion.div variants={navItemVariants} whileHover="hover" whileTap="tap">
                        <Button variant="ghost" asChild><Link to="/teacher/questions"><Edit3 className="mr-2 h-4 w-4" />Questions</Link></Button>
                      </motion.div>
                      <motion.div variants={navItemVariants} whileHover="hover" whileTap="tap">
                        <Button variant="ghost" asChild><Link to="/teacher/exams"><FileText className="mr-2 h-4 w-4" />Exams</Link></Button>
                      </motion.div>
                    </>
                  )}
                  {user.role === ROLES.STUDENT && (
                     <>
                      <motion.div variants={navItemVariants} whileHover="hover" whileTap="tap">
                        <Button variant="ghost" asChild><Link to="/student"><LayoutDashboard className="mr-2 h-4 w-4" />Dashboard</Link></Button>
                      </motion.div>
                      <motion.div variants={navItemVariants} whileHover="hover" whileTap="tap">
                        <Button variant="ghost" asChild><Link to="/student/exams"><BookOpenCheck className="mr-2 h-4 w-4" />Available Exams</Link></Button>
                      </motion.div>
                    </>
                  )}
                  <motion.div variants={navItemVariants} whileHover="hover" whileTap="tap">
                    <Button variant="ghost" asChild><Link to="/profile"><User className="mr-2 h-4 w-4" />Profile</Link></Button>
                  </motion.div>
                  <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                    <Button onClick={handleLogout} variant="destructive"><LogOut className="mr-2 h-4 w-4" />Logout</Button>
                  </motion.div>
                </>
              ) : (
                <>
                  <motion.div variants={navItemVariants} whileHover="hover" whileTap="tap">
                    <Button variant="ghost" asChild><Link to="/login">Login</Link></Button>
                  </motion.div>
                  <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                    <Button asChild><Link to="/register">Register</Link></Button>
                  </motion.div>
                </>
              )}
            </div>
          </div>
        </nav>
      );
    };

    export default Navbar;
  