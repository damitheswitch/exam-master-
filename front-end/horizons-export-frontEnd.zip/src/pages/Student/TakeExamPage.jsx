
    import React, { useState, useEffect, useContext, useCallback } from 'react';
    import { useParams, useNavigate } from 'react-router-dom';
    import { AuthContext } from '@/App';
    import { Button } from '@/components/ui/button';
    import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
    import { Checkbox } from '@/components/ui/checkbox';
    import { Label } from '@/components/ui/label';
    import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'; 
    import { useToast } from '@/components/ui/use-toast';
    import { motion, AnimatePresence } from 'framer-motion';
    import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
    import { AlertTriangle, CheckCircle, Clock } from 'lucide-react';

    const TakeExamPage = () => {
      const { examId } = useParams();
      const navigate = useNavigate();
      const { user } = useContext(AuthContext);
      const { toast } = useToast();

      const [exam, setExam] = useState(null);
      const [questions, setQuestions] = useState([]);
      const [answers, setAnswers] = useState({}); 
      const [timeLeft, setTimeLeft] = useState(0);
      const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
      const [isTabSwitchWarningOpen, setIsTabSwitchWarningOpen] = useState(false);
      const [isTimeUpAlertOpen, setIsTimeUpAlertOpen] = useState(false);
      const [isSubmitting, setIsSubmitting] = useState(false);
      const [direction, setDirection] = useState(0);

      useEffect(() => {
        const allExams = JSON.parse(localStorage.getItem('exammaster_exams') || '[]');
        const currentExam = allExams.find(ex => ex.id === examId);

        if (!currentExam || !currentExam.published) {
          toast({ variant: "destructive", title: "Error", description: "Exam not found or not available." });
          navigate('/student/exams');
          return;
        }
        
        const submissions = JSON.parse(localStorage.getItem('exammaster_submissions') || '[]');
        const existingSubmission = submissions.find(sub => sub.examId === examId && sub.studentId === user.id);
        if (existingSubmission) {
            toast({ title: "Exam Already Taken", description: "You have already submitted this exam." });
            navigate(`/student/results/${existingSubmission.id}`);
            return;
        }


        setExam(currentExam);
        setTimeLeft(currentExam.duration * 60);

        const allQuestions = JSON.parse(localStorage.getItem('exammaster_questions') || '[]');
        const examQuestions = allQuestions.filter(q => currentExam.selectedQuestionIds.includes(q.id));
        setQuestions(examQuestions);

        const initialAnswers = {};
        examQuestions.forEach(q => {
          initialAnswers[q.id] = q.type === 'multiple-choice' ? [] : '';
        });
        setAnswers(initialAnswers);

      }, [examId, navigate, toast, user?.id]);

      useEffect(() => {
        if (timeLeft <= 0 && exam) { 
          if (!isSubmitting) { 
            setIsTimeUpAlertOpen(true);
          }
          return;
        }
        const timer = setInterval(() => {
          setTimeLeft(prevTime => prevTime - 1);
        }, 1000);
        return () => clearInterval(timer);
      }, [timeLeft, exam, isSubmitting]);
      
      const handleVisibilityChange = useCallback(() => {
        if (document.hidden && timeLeft > 0 && !isSubmitting) {
          setIsTabSwitchWarningOpen(true);
          toast({
            variant: "destructive",
            title: "Warning: Tab Switch Detected",
            description: "Switching tabs during an exam is not allowed and may be penalized.",
            duration: 10000,
          });
        }
      }, [timeLeft, toast, isSubmitting]);

      useEffect(() => {
        document.addEventListener('visibilitychange', handleVisibilityChange);
        return () => {
          document.removeEventListener('visibilitychange', handleVisibilityChange);
        };
      }, [handleVisibilityChange]);


      const handleAnswerChange = (questionId, value, questionType) => {
        setAnswers(prev => {
          const newAnswers = { ...prev };
          if (questionType === 'multiple-choice') {
            const currentSelection = newAnswers[questionId] || [];
            if (currentSelection.includes(value)) {
              newAnswers[questionId] = currentSelection.filter(v => v !== value);
            } else {
              newAnswers[questionId] = [...currentSelection, value];
            }
          } else { 
            newAnswers[questionId] = value;
          }
          return newAnswers;
        });
      };

      const calculateScore = () => {
        let score = 0;
        let totalPossibleScore = 0;
      
        questions.forEach(q => {
          totalPossibleScore += (q.points || 1);
          const studentAnswer = answers[q.id];
          const correctOptions = q.options.filter(opt => opt.isCorrect).map(opt => opt.text);
      
          if (q.type === 'single-choice') {
            if (studentAnswer && correctOptions.includes(studentAnswer)) {
              score += (q.points || 1);
            }
          } else if (q.type === 'multiple-choice') {
            if (studentAnswer && studentAnswer.length > 0) {
              const sortedStudentAnswers = [...studentAnswer].sort();
              const sortedCorrectOptions = [...correctOptions].sort();
              if (JSON.stringify(sortedStudentAnswers) === JSON.stringify(sortedCorrectOptions)) {
                score += (q.points || 1);
              }
            }
          }
        });
        const percentage = totalPossibleScore > 0 ? Math.round((score / totalPossibleScore) * 100) : 0;
        return { score, totalPossibleScore, percentage };
      };

      const submitExam = useCallback(() => {
        if (isSubmitting) return;
        setIsSubmitting(true);

        const scoreData = calculateScore();
        const submission = {
          id: Date.now().toString(),
          examId,
          studentId: user.id,
          studentName: user.name,
          answers,
          submittedAt: new Date().toISOString(),
          scoreData,
          examTitle: exam.title,
        };

        const submissions = JSON.parse(localStorage.getItem('exammaster_submissions') || '[]');
        submissions.push(submission);
        localStorage.setItem('exammaster_submissions', JSON.stringify(submissions));

        toast({
          title: "Exam Submitted!",
          description: `Your score: ${scoreData.score}/${scoreData.totalPossibleScore} (${scoreData.percentage}%)`,
          duration: 10000,
          action: (
            <Button onClick={() => navigate(`/student/results/${submission.id}`)}>View Details</Button>
          )
        });
        navigate(`/student/results/${submission.id}`);
      }, [isSubmitting, examId, user, answers, questions, toast, navigate, exam?.title]);


      useEffect(() => {
        if (isTimeUpAlertOpen && !isSubmitting) {
           submitExam();
        }
      }, [isTimeUpAlertOpen, submitExam, isSubmitting]);


      if (!exam || questions.length === 0) {
        return (
          <div className="flex items-center justify-center min-h-[calc(100vh-200px)]">
            <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
            <p className="ml-4 text-slate-300">Loading exam...</p>
          </div>
        );
      }
      
      const currentQuestion = questions[currentQuestionIndex];
      const formatTime = (seconds) => {
        const m = Math.floor(seconds / 60);
        const s = seconds % 60;
        return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
      };

      const questionVariants = {
        enter: (directionParam) => ({
          x: directionParam > 0 ? 300 : -300,
          opacity: 0
        }),
        center: {
          zIndex: 1,
          x: 0,
          opacity: 1
        },
        exit: (directionParam) => ({
          zIndex: 0,
          x: directionParam < 0 ? 300 : -300,
          opacity: 0
        })
      };
      
      const paginate = (newDirection) => {
        setDirection(newDirection);
        setCurrentQuestionIndex(prev => Math.max(0, Math.min(questions.length - 1, prev + newDirection)));
      };


      return (
        <div className="max-w-4xl mx-auto py-8">
          <Card className="bg-slate-800/80 border-slate-700 shadow-2xl backdrop-blur-sm">
            <CardHeader className="flex flex-row justify-between items-center border-b border-slate-700 pb-4">
              <div>
                <CardTitle className="text-3xl font-bold gradient-text">{exam.title}</CardTitle>
                <CardDescription className="text-slate-400">Subject: {exam.subject}</CardDescription>
              </div>
              <div className={`text-2xl font-semibold p-2 rounded-md ${timeLeft <= 60 ? 'text-red-500 animate-pulse' : 'text-green-400'} bg-slate-700 shadow-inner`}>
                <Clock className="inline mr-2 h-6 w-6" /> {formatTime(timeLeft)}
              </div>
            </CardHeader>
            <CardContent className="pt-6 relative min-h-[350px] overflow-hidden">
              <AnimatePresence initial={false} custom={direction} mode="wait">
                <motion.div
                  key={currentQuestionIndex}
                  custom={direction}
                  variants={questionVariants}
                  initial="enter"
                  animate="center"
                  exit="exit"
                  transition={{
                    x: { type: "spring", stiffness: 300, damping: 30 },
                    opacity: { duration: 0.2 }
                  }}
                  className="w-full" 
                >
                  <h2 className="text-xl font-semibold text-slate-100 mb-1">Question {currentQuestionIndex + 1} of {questions.length} <span className="text-sm text-slate-400">({currentQuestion.points || 1} points)</span></h2>
                  <p className="text-lg text-slate-300 mb-6">{currentQuestion.text}</p>
                  
                  {currentQuestion.type === 'single-choice' ? (
                    <RadioGroup
                      value={answers[currentQuestion.id] || ''}
                      onValueChange={(value) => handleAnswerChange(currentQuestion.id, value, 'single-choice')}
                      className="space-y-3"
                    >
                      {currentQuestion.options.map((opt, idx) => (
                        <Label key={idx} htmlFor={`opt-${currentQuestion.id}-${idx}`} className="flex items-center p-3 border border-slate-600 rounded-md hover:bg-slate-700/50 transition-colors cursor-pointer has-[:checked]:bg-primary/20 has-[:checked]:border-primary">
                          <RadioGroupItem value={opt.text} id={`opt-${currentQuestion.id}-${idx}`} className="mr-3 border-slate-500 text-primary focus:ring-primary" />
                          {opt.text}
                        </Label>
                      ))}
                    </RadioGroup>
                  ) : ( 
                    <div className="space-y-3">
                      {currentQuestion.options.map((opt, idx) => (
                        <Label key={idx} htmlFor={`opt-${currentQuestion.id}-${idx}`} className="flex items-center p-3 border border-slate-600 rounded-md hover:bg-slate-700/50 transition-colors cursor-pointer has-[:checked]:bg-primary/20 has-[:checked]:border-primary">
                          <Checkbox
                            id={`opt-${currentQuestion.id}-${idx}`}
                            checked={(answers[currentQuestion.id] || []).includes(opt.text)}
                            onCheckedChange={() => handleAnswerChange(currentQuestion.id, opt.text, 'multiple-choice')}
                            className="mr-3 border-slate-500 data-[state=checked]:bg-primary data-[state=checked]:border-primary"
                          />
                          {opt.text}
                        </Label>
                      ))}
                    </div>
                  )}
                </motion.div>
              </AnimatePresence>
            </CardContent>
            <div className="flex justify-between items-center p-6 border-t border-slate-700">
              <Button onClick={() => paginate(-1)} disabled={currentQuestionIndex === 0} variant="outline" className="text-slate-300 border-slate-600 hover:bg-slate-700">Previous</Button>
              <p className="text-sm text-slate-400">Question {currentQuestionIndex + 1} / {questions.length}</p>
              {currentQuestionIndex < questions.length - 1 ? (
                <Button onClick={() => paginate(1)} variant="outline" className="text-slate-300 border-slate-600 hover:bg-slate-700">Next</Button>
              ) : (
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-500/90 hover:to-emerald-600/90 text-white">
                      <CheckCircle className="mr-2 h-5 w-5" /> Submit Exam
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent className="bg-slate-800 border-slate-700 text-slate-50">
                    <AlertDialogHeader>
                      <AlertDialogTitle className="text-emerald-400">Confirm Submission</AlertDialogTitle>
                      <AlertDialogDescription className="text-slate-400">
                        Are you sure you want to submit your answers? You cannot make changes after submission.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel className="text-slate-300 border-slate-600 hover:bg-slate-700">Review Answers</AlertDialogCancel>
                      <AlertDialogAction onClick={submitExam} className="bg-emerald-500 hover:bg-emerald-600">
                        Yes, submit now
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              )}
            </div>
          </Card>

          <AlertDialog open={isTabSwitchWarningOpen} onOpenChange={setIsTabSwitchWarningOpen}>
            <AlertDialogContent className="bg-slate-800 border-slate-700 text-slate-50">
              <AlertDialogHeader>
                <AlertDialogTitle className="text-yellow-400 flex items-center"><AlertTriangle className="mr-2" /> Tab Switch Detected</AlertDialogTitle>
                <AlertDialogDescription className="text-slate-400">
                  You have switched away from the exam tab. Please remain on this page to avoid issues with your exam. Further tab switches may be penalized.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogAction onClick={() => setIsTabSwitchWarningOpen(false)} className="bg-yellow-500 hover:bg-yellow-600">I Understand</AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>

          <AlertDialog open={isTimeUpAlertOpen} onOpenChange={setIsTimeUpAlertOpen}>
            <AlertDialogContent className="bg-slate-800 border-slate-700 text-slate-50">
              <AlertDialogHeader>
                <AlertDialogTitle className="text-red-500 flex items-center"><Clock className="mr-2" /> Time's Up!</AlertDialogTitle>
                <AlertDialogDescription className="text-slate-400">
                  The time for this exam has expired. Your answers will be submitted automatically.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogAction onClick={() => { setIsTimeUpAlertOpen(false); if(!isSubmitting) submitExam(); }} className="bg-red-500 hover:bg-red-600">
                  OK
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      );
    };
    
    export default TakeExamPage;
  